package konid.soxzz5.fitfood.utils;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by Soxzer on 13/12/2016.
 */

class addingredient extends View {

    public addingredient(Context context, AttributeSet attrs)
    {
        super(context,attrs);
    }
}
